package org.jenkinsci.plugins.neoload.integration;

import static org.junit.Assert.*;

import org.junit.Test;

public class NeoBuildActionTest {

	@Test
	public void testUpdateUsingUniqueID() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrepareCommandLine() {
		fail("Not yet implemented");
	}

}
